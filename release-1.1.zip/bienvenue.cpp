#include <iostream>

int main() { 
    std::cout << "Benvengit initue le monde !" << std::endl;
    return 0; 
}
