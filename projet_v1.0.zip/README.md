# Bienvenue
Programme C++ qui affiche "Bienvenue le monde !"